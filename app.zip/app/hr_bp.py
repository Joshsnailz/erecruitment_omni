from flask import Blueprint, render_template
from flask_login import login_required, current_user 

hr_bp = Blueprint('hr_bp', __name__)

@hr_bp.route('/hr')
@login_required
def index_hr():
    return render_template('hr/index.html', title="Human Resource Admin", name=current_user.name)

@hr_bp.route('/applicant')
def applicant():
	return render_template('common/pages-clients.html')


@hr_bp.route('/view-cv')
def view_cv():
	return render_template('common/pages-invoice.html')

@hr_bp.route('/applicants')
def applicants():
	return render_template('common/pages-tasks.html')


@hr_bp.route('/hr-chat')
def hr_chat():
	return render_template('common/pages-chat.html')


@hr_bp.route('/settings')
def settings_hr():
	return render_template('hr/pages-settings.html')

@hr_bp.route('/add_job')
def add_job():
	return render_template('hr/add_job.html')

	



