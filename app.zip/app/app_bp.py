from flask import Blueprint, render_template , redirect, url_for, request, flash 
from werkzeug.security import generate_password_hash, check_password_hash 
from flask_login import login_user, current_user, logout_user, login_required
from .models import User
from . import db 
from .forms import RegistrationForm, LoginForm

app_bp = Blueprint('app',__name__)



jobs = [
    {
        'Title': 'Team Leader BPO',
        'Department': 'Outbound Sourcing',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    },
    {
        'Title': 'SHE Officer',
        'Department': 'Call Centre Management',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    },
    {
        'Title': 'Digital Marketing Officer',
        'Department': 'OmniContact Digital',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    },
    {
        'Title': 'Team Leader BPO',
        'Department': 'Outbound Sourcing',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    },
    {
        'Title': 'SHE Officer',
        'Department': 'Call Centre Management',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    },
    {
        'Title': 'Digital Marketing Officer',
        'Department': 'OmniContact Digital',
        'Qualifications': 'First post content',
        'Key_Responsibilities': 'April 20, 2018',
        'Due_Date': '19-20-1994'
    }
    
]

@app_bp.route('/')
def home():
	form = LoginForm()
	return render_template('base/home.html', form=form, jobs=jobs)


@app_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('candidate.candidate_index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('candidate.candidate_index'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    return render_template('base/home.html', title='Login', form=form)



@app_bp.route('/signup', methods=['POST','GET'])
def signup():
    if current_user.is_authenticated:
        return redirect(url_for('candidate.candidate_index'))
    form = RegistrationForm()
    if form.validate_on_submit():
    	password = form.password.data
    	user = User.query.filter_by(email=form.email.data).first()
    	if not user:
    		user = User(name=form.name.data, email=form.email.data, password=generate_password_hash(password, method='sha256'))
    		db.session.add(user)
    		db.session.commit()
    		flash('Your account has been created! You are now able to log in', 'success')
    		return redirect(url_for('app.login'))
    	else:
    		flash(f'Email acccount already in use, kindly login! or choose another', 'danger')
    		return redirect(url_for('app.login'))

    return render_template('base/signup.html', title='Sign up', form=form)

@app_bp.route('/reset-password')
def reset_pass():
	return render_template('common/pages-reset-password.html')


@app_bp.route('/calendar')
def calendar():
	return render_template('common/calendar.html')

@app_bp.route('/jobs')
def job():
	return render_template('common/jobs.html', jobs=jobs)


@app_bp.route('/logout')
@login_required
def logout():
	logout_user()
	flash(f'You have successfully logged out', 'success')
	return redirect(url_for('app.home'))