from flask import Blueprint, render_template
from flask_login import login_required, current_user 

candidate_bp = Blueprint('candidate',__name__)

@candidate_bp.route('/candidate')
@login_required
def candidate_index(): 
    return render_template('candidate/index.html', name=current_user.name, title ='Candidate | Home')



@candidate_bp.route('/profile/')
@login_required
def profile():
	name = current_user.name
	return render_template('candidate/profile.html', name=name)

@candidate_bp.route('/settings')
@login_required
def settings():
	name = current_user.name
	return render_template('candidate/candidate-settings.html', name=name)

@candidate_bp.route('/my-jobs')
@login_required
def my_jobs_applied():
	return render_template('candidate/my-jobs-applied.html', name=current_user.name)

@candidate_bp.route('/cv')
@login_required
def my_cv():
	return render_template('candidate/my-cv.html',name=current_user.name)

@candidate_bp.route('/favorite-jobs')
@login_required
def my_jobs_favorite():
	return render_template('candidate/my-jobs-favorite.html', name=current_user.name)


@candidate_bp.route('/chat')
@login_required
def chat():
	return render_template('candidate/chat.html', name=current_user.name)

@candidate_bp.route('/tasks')
@login_required
def tasks():
	return render_template('candidate/tasks.html',name=current_user.name)

@candidate_bp.route('/apply')
@login_required
def apply_job():
	return "you have applied " 



